//2F_362258302037_Sandi Sukoco Putro

import 'package:flutter/material.dart';
import 'ui/produk_form.dart';

void main() {
  runApp(MaterialApp(
    title: "Latihan Flutter 23 9 23",
    //delete debug banner
    debugShowCheckedModeBanner: false,
    home: ProdukForm(),
  ));
}
